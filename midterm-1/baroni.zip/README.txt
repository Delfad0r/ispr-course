INSTRUCTIONS

Simply put "font.fft" in the same folder as "pitch-detector.py" and run
    python3 pitch-detector.py


REQUIREMENTS

The following Python libraries are required:
  * numpy
  * pyaudio
  * pyglet
